public class Main {
    public static void main(String[] args) {
        double radius = 1;

    }
        // write code here
        public static void area(double radius){
            if (radius > -1.0){
                System.out.println("Invalid Value");
            }
            else {
                System.out.println("valid Value");
            }
        }

    }

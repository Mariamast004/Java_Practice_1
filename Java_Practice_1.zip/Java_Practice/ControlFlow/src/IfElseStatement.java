public class IfElseStatement {
    public static void main(String[] args) {
        int value = 2;
        if (value == 1){
            System.out.println("Value was 1");

        } else if (value == 2); {
            System.out.println("Value was 2");

        }

    }
}

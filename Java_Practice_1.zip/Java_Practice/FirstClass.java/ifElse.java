public class ifElse {
    public static void main(String [] args){
        // demostrate if Else
        class IfElse{
            public static void main(String [] args) {

                int time = 22;
                if (time < 10) {
                    System.out.println("Good Morning");
                } else if (time <18) {
                    System.out.println("Good Day");
                } else {
                    System.out.println("Good Evening");
                }

            }
}

public class FirstClass {
    public static void main(String[] args) {
        double c=3;
        int a =10, b= 20;



        System.out.println("Sum" + (a + b));
        System.out.println("Substract" + (b-c));
        System.out.println("Multiply" + (a * c));
        System.out.println("Divide" + (b / c));

        String message = ("Hello World");
        System.out.println(message);

      //  int number1 =20;




    }
}
// demostrate IfElse, ElseIf statement
class IfElse{
    public static void main(String [] args) {

       int time = 22;
       if (time < 10) {
           System.out.println("Good Morning");
       } else if (time <18) {
           System.out.println("Good Day");
       } else {
           System.out.println("Good Evening");
       }


    }
}
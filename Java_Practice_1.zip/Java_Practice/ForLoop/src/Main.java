public class Main {
    public static void main(String[] args) {
        for (int numbers = 1; numbers <=5; numbers++) {
            System.out.println(numbers);
        }
    }

}
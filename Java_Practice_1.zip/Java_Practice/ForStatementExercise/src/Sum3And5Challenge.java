public class Sum3And5Challenge {
    public static void main(String[] args) {
        int countOfMatches = 0;
        int sumOfMatches = 0;

        for (int loopNumber = 1; loopNumber <= 1000; loopNumber++){
            if ((loopNumber % 3 == 0) &&  (loopNumber % 5 ==0)) {
                countOfMatches++;
                sumOfMatches += loopNumber;
                System.out.println("Found a match = " + loopNumber);

            }
            if (countOfMatches == 50){
                break;
            }

        }
        System.out.println("sum = " + sumOfMatches);

        for(int number =0; number  < 5; number++);
        {
            System.out.println(number);
        }
    }
}

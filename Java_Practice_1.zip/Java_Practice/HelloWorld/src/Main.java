import java.lang.reflect.Array;
import java.util.Arrays;

/* HelloWorld Program */
public class Main {
    public static void main(String[] args) {
        int topScore = 80;
        if (topScore < 100) {
            System.out.println("You got the highest score");
        }

        int secondTopScore = 81;
        if ((topScore > secondTopScore) && (topScore < 100)) {
            System.out.println("Greater than second to score and less than 100");
        }
        if ((topScore > 90) || (secondTopScore <= 90)) {
            System.out.println("Either both of the conditions are true");
        }
        double myFirstValue = 20.00d;
        double mySecondValue = 80.00d;
        double myValuesTotal = myFirstValue + mySecondValue * 100.00d;
        System.out.println("MyValuesTotal =" + myValuesTotal);
        double theRemainder = myValuesTotal % 40.00d;
        System.out.println("theRemainder = " + theRemainder);
        boolean isNoRemainder = (theRemainder == 0)? true : false;
        System.out.println("isRemainder =" + isNoRemainder);

        String Greetings = "Message";
        System.out.println ("Greetings");
        {
            String message = ("Hello \"Mariam\"");
            System.out.println(message);
        }




        int [] numbers = new int [5];
        numbers [0] =1;
        numbers [1] = 2;

                System.out.println(Arrays. toString(numbers));

                 int[] myNum = {10, 20, 30, 35, 40};

                         System.out.println(Arrays.toString(myNum));

        String [] cars = {"Volvo", "BMW", "Ford", "Mazda"};
        System.out.println(cars.length);




    }

}

import java.sql.SQLOutput;

public class Main {
    public  static  void main(String[] args){
        int time = 22;
        if (time < 10) {
            System.out.println("Good Morning");
        } else if (time <18) {
            System.out.println("Good Day");
        } else {
            System.out.println("Good Evening");
        }

        int topScore = 80;
        if (topScore ==80){
            System.out.println("You score the highest score");
        } else{
System.out.println("You Score the lowest grade");
            }
int secondTopScore =81;
        if (topScore>secondTopScore || topScore < 100){
            System.out.println("Greater than second top score and less than 100");
        }
boolean isMariama = false;
        if(!isMariama){
            System.out.println("She is not a girl");
        } else if (!isMariama) {
            System.out.println("She is a lady");

        }
        int ageOfClient = 20;
        String ageText = ageOfClient <= 18 ? "Over Eighteen" : "Still a Kid";
        System.out.println("Our Client is" + ageText);

        double a= 20.00;
        double b= 80.00;
        double myValuesTotal = a + b * 100.00;

        System.out.println("MyValuesTotal = " + myValuesTotal);
        double theRemainder = myValuesTotal % 40.00;
        System.out.println("theRemainder = " + theRemainder);
        boolean isNoRemainder = (theRemainder == 0) ? true : false;
        System.out.println("theNoRemainder = " + isNoRemainder);
        if (!isNoRemainder) {
            System.out.println("Got some Remainder");
        }

        int myVariable = 50;
        myVariable++;
        myVariable--;
        System.out.println("This is a test");

        boolean gameover = true;
        int score = 5000;
        int levelCompleted = 5;
        int bonus = 100;
        if (score < 5000 && score > 1000) {
            System.out.println("Your score was less than 5000");
        } else if (score < 100) {
            System.out.println("Your score was less than 1000");
            
        } else {
              System.out.println("Got here");
        }

    }
    public static boolean isTooYoung(int age){

        if (age <21){
            return true;
        }else {
            return false;
        }

    }



}


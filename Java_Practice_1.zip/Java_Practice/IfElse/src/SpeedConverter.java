
public class SpeedConverter {
    public static void main(String [] args){

    }
    // write code here

   public static long toMilesPerHour(double kilometersPerHour){
        if (kilometersPerHour < 0)
            return -1;

        double kilometersPerHours = 1.609;
       return Math.round(kilometersPerHours/1.609);




   }
   public  static void printConversion(double kiloMetersPerHours){
        if (kiloMetersPerHours < 0) {
            System.out.println("Invalid Value");
            return;
        }
          long milesPerHour = toMilesPerHour(kiloMetersPerHours);
          System.out.println(kiloMetersPerHours + "km/h = " + milesPerHour + "mi/h");


        }
   }


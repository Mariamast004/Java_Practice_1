public class Main {
    public static void main(String[] args) {
      String name = "Mariama Mansaray";
      String country = "Sierra Leone ";
      int age = 25;
      String company = "Ubuntu";
      double gpa = 3.8;

      //String formattedString = String.format("My name is %s. I am from %s. I am %d years old. I work for % s", name, country, age, country);
        System.out.println("Hello World! I am "  + name + " I am from " + country + " and I am " + age + " years old, I work for " + company + " My grade point is " + gpa + "."  );
        //System.out.println(formattedString);

    }
}
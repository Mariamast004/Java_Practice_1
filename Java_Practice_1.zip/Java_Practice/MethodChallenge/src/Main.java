public class Main {
    public static void checkAge(int age){
        if (age < 10){
            System.out.println("access denied");
        }
        else {
            System.out.println("grant access ");
        }
    }
    public static void main(String[] args) {
        checkAge(20);
        myMethod("Mariama");

    }
    public static void myMethod(String fname){
        System.out.println("My name is " + fname + ".");

    }
}
public class MethodChallenge1 {
    public static void main(String[] args) {
       double mynum1 = plusMethod(20.5, 22.5);
       int mynum2 = plusMethod(10, 5);
        System.out.println(" int: " + mynum2);
        System.out.println(" double: " + mynum1 );

    }
    public static double plusMethod(double x, double y){
        return x + y;
    }
    public static  int plusMethod(int x, int y){
        return x * y;
    }

}

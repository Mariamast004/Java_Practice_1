public class StringChallange {
    public static void main(String[] args) {
        String name = "Mariama Mansaray";
        String country = "Sierra Leonean";
        String company = "Ubuntu";
        int age = 25;
        double gpa = 4.5;
        System.out.println("My name is  " + name +  ",");
        System.out.println(  " I am a " + country + " I work in  " + company + ", And I am " + age + " years Old, and My grade point is " + gpa + ".");

    }

}

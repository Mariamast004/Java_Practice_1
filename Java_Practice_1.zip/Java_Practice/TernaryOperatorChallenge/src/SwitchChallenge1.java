import java.util.Scanner;
public class SwitchChallenge1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int age;
        age = scanner.nextInt();
        if (age >= 18) {

            switch (age) {
                case (16):
                    System.out.println("You are not an adult");
                    break;
                case (18):
                    System.out.println("You are an adult");
                    break;
                case (65):
                    System.out.println("You are senior citizen");
                    break;
                default: {
                    System.out.println("Please give the valid age");
                    break;
                }
            }
        }
    }
}

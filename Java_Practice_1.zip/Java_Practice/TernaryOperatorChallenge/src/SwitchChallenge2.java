import java.util.Scanner;
public class SwitchChallenge2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
      int year;
      year = scanner.nextInt();
        String Branch = "CS";
        switch (year){
            case  1:
                System.out.println("Elected Courses : Advance Maths , Algebra, Science Core ");
                break;

            case 2:
                switch (Branch){
                    case "CS":
                    case "ECE":
                        System.out.println("Elective Courses : ML, Big Data ");
                        break;

                    default:
                    {
                        System.out.println("Invalid input");
                    }
                }

        }



    }



    }


import java.util.Scanner;

public class SwitchChallenge3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a age Number");
        int age;
        age = scanner.nextInt();
        if (age <= 15) {
            System.out.println("You are still a kid");
        } else if (age == 16 || age == 17) {
            System.out.println("You are almost an adult");
        } else if (age == 18 || age <= 64){
            System.out.println("You are an adult");
        } else {
            System.out.println("You are a citizen");
        }
    }
}

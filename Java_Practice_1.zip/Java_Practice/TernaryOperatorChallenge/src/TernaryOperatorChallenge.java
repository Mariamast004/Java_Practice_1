public class TernaryOperatorChallenge {
    public static void main(String[] args) {
        boolean isMariama = true;
        String result = isMariama? "True" : "false ";
        System.out.println(result);


        int age = 18;
       // String result = age <= 17 ? "allowed to pass" : "not allowed to pass" ;
        //System.out.println(result);
        if (age <= 18) {
            System.out.println("access denied");
        }
        else {
            System.out.println("access allowed");
        }

    }
}
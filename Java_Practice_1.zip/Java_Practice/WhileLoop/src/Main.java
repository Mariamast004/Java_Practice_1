public class Main {
    public static void main(String[] args) {

        for(int numbers = 1; numbers <= 5; numbers++){
            System.out.println(numbers);
        }
        int i =0;
        while (i <= 5){
            System.out.println(i);
            i++;
        }
        int j = 1;
        while (true){
            if (j > 5) {
                break;
            }
            System.out.println(j);
            j++;
        }
    }
}
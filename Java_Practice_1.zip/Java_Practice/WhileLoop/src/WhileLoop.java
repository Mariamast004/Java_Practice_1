public class WhileLoop {
    public static boolean isEvenNumber (int num){

    }
}
